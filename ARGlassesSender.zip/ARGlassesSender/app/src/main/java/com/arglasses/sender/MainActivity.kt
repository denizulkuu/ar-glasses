package com.arglasses.sender

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * Entry point UI. Lets the user type in the ESP32 receiver's IP address,
 * requests screen-capture (MediaProjection) permission from the system,
 * and starts/stops the background [ScreenCaptureService] that does the
 * actual capture -> JPEG encode -> UDP fragment/send work.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var ipInput: EditText
    private lateinit var statusText: TextView
    private lateinit var startStopButton: Button

    private var isStreaming = false

    private lateinit var projectionManager: MediaProjectionManager

    // Launches the system "Start recording your screen?" permission dialog.
    // On success, the resulting Intent (resultData) is what the service
    // needs to actually create the MediaProjection instance.
    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                startCaptureService(result.resultCode, result.data!!)
            } else {
                Toast.makeText(this, "Screen capture permission denied.", Toast.LENGTH_LONG).show()
                setStreamingUiState(false)
            }
        }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* no-op, best effort */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ipInput = findViewById(R.id.ipAddressInput)
        statusText = findViewById(R.id.statusText)
        startStopButton = findViewById(R.id.startStopButton)

        projectionManager =
            getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        requestNotificationPermissionIfNeeded()

        startStopButton.setOnClickListener {
            if (!isStreaming) {
                beginStreamingFlow()
            } else {
                stopStreaming()
            }
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this, Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun beginStreamingFlow() {
        val ip = ipInput.text.toString().trim()
        if (!isValidIpAddress(ip)) {
            Toast.makeText(this, "Enter a valid IP address first.", Toast.LENGTH_SHORT).show()
            return
        }
        // Stash the target IP where the service can read it back after the
        // permission round-trip completes.
        getSharedPreferences("ar_glasses_prefs", MODE_PRIVATE)
            .edit()
            .putString("target_ip", ip)
            .apply()

        projectionLauncher.launch(projectionManager.createScreenCaptureIntent())
    }

    private fun startCaptureService(resultCode: Int, data: Intent) {
        val ip = ipInput.text.toString().trim()
        val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_START
            putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
            putExtra(ScreenCaptureService.EXTRA_TARGET_IP, ip)
        }
        ContextCompat.startForegroundService(this, serviceIntent)
        setStreamingUiState(true)
    }

    private fun stopStreaming() {
        val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_STOP
        }
        startService(serviceIntent)
        setStreamingUiState(false)
    }

    private fun setStreamingUiState(streaming: Boolean) {
        isStreaming = streaming
        startStopButton.text = if (streaming) "Stop Streaming" else "Start Streaming"
        statusText.text = if (streaming) "Status: streaming" else "Status: idle"
    }

    private fun isValidIpAddress(ip: String): Boolean {
        val parts = ip.split(".")
        if (parts.size != 4) return false
        return parts.all { part ->
            part.toIntOrNull()?.let { it in 0..255 } ?: false
        }
    }
}
