package com.arglasses.sender

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.io.ByteArrayOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Foreground service that owns the full sender pipeline:
 *
 *   MediaProjection -> VirtualDisplay -> ImageReader (RGBA_8888)
 *     -> Bitmap -> JPEG encode -> UDP fragmentation -> DatagramSocket
 *
 * The VirtualDisplay is created directly at the receiver's panel resolution
 * (240x320), so the system compositor does the downscale from the phone's
 * native screen resolution for us - no manual bitmap scaling needed.
 *
 * Wire format (must match AR_Glasses_Receiver.ino exactly):
 *   Header (10 bytes, little-endian):
 *     uint16 magic          = 0xA55A
 *     uint16 frameId
 *     uint16 packetId
 *     uint16 totalPackets
 *     uint16 payloadLen
 *   followed by `payloadLen` bytes of raw JPEG fragment data.
 */
class ScreenCaptureService : Service() {

    companion object {
        const val ACTION_START = "com.arglasses.sender.action.START"
        const val ACTION_STOP = "com.arglasses.sender.action.STOP"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val EXTRA_TARGET_IP = "extra_target_ip"

        private const val NOTIFICATION_CHANNEL_ID = "ar_glasses_stream"
        private const val NOTIFICATION_ID = 1

        // --- Must match ESP32 config exactly ---
        private const val PANEL_WIDTH = 240
        private const val PANEL_HEIGHT = 320
        private const val UDP_PORT = 5005
        private const val PACKET_MAGIC: Int = 0xA55A
        private const val HEADER_BYTES = 10
        private const val MAX_PACKET_BYTES = 1400
        private const val MAX_PAYLOAD_BYTES = MAX_PACKET_BYTES - HEADER_BYTES // 1390
        private const val MAX_FRAME_BYTES = 60 * 1024

        // Target frame pacing (30 FPS -> ~33ms minimum spacing between frames).
        private const val MIN_FRAME_INTERVAL_MS = 33L
    }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var captureThread: HandlerThread? = null
    private var captureHandler: Handler? = null

    private var socket: DatagramSocket? = null
    private var targetAddress: InetAddress? = null

    private var frameId: Int = 0
    private var lastFrameSentAtMs: Long = 0

    private val projectionManager: MediaProjectionManager by lazy {
        getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> handleStart(intent)
            ACTION_STOP -> handleStop()
        }
        return START_NOT_STICKY
    }

    private fun handleStart(intent: Intent) {
        startForeground(NOTIFICATION_ID, buildNotification())

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, -1)
        val resultData: Intent? =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(EXTRA_RESULT_DATA)
            }
        val targetIp = intent.getStringExtra(EXTRA_TARGET_IP)

        if (resultData == null || targetIp.isNullOrEmpty()) {
            stopSelf()
            return
        }

        try {
            targetAddress = InetAddress.getByName(targetIp)
            socket = DatagramSocket()
        } catch (e: Exception) {
            stopSelf()
            return
        }

        captureThread = HandlerThread("ScreenCaptureThread").also { it.start() }
        captureHandler = Handler(captureThread!!.looper)

        mediaProjection = projectionManager.getMediaProjection(resultCode, resultData)
        mediaProjection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                handleStop()
            }
        }, captureHandler)

        setupVirtualDisplay()
    }

    private fun setupVirtualDisplay() {
        val density = resources.displayMetrics.densityDpi

        imageReader = ImageReader.newInstance(
            PANEL_WIDTH, PANEL_HEIGHT, PixelFormat.RGBA_8888, 2
        )

        imageReader?.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val now = System.currentTimeMillis()
                if (now - lastFrameSentAtMs < MIN_FRAME_INTERVAL_MS) {
                    // Drop this frame to hold pacing near 30 FPS and avoid
                    // flooding the network faster than the receiver can
                    // decode/display.
                    return@setOnImageAvailableListener
                }
                lastFrameSentAtMs = now

                val bitmap = imageToBitmap(image)
                val jpegBytes = compressToJpegWithinBudget(bitmap)
                if (jpegBytes != null) {
                    sendFrame(jpegBytes)
                }
                bitmap.recycle()
            } finally {
                image.close()
            }
        }, captureHandler)

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "ARGlassesCapture",
            PANEL_WIDTH, PANEL_HEIGHT, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            captureHandler
        )
    }

    /**
     * Converts an RGBA_8888 [android.media.Image] from the ImageReader into
     * a [Bitmap], accounting for row stride padding that ImageReader planes
     * commonly include (width in the buffer can exceed the logical image
     * width for byte-alignment reasons).
     */
    private fun imageToBitmap(image: android.media.Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * PANEL_WIDTH

        val bitmap = Bitmap.createBitmap(
            PANEL_WIDTH + rowPadding / pixelStride,
            PANEL_HEIGHT,
            Bitmap.Config.ARGB_8888
        )
        bitmap.copyPixelsFromBuffer(buffer)

        return if (rowPadding == 0) {
            bitmap
        } else {
            // Crop away the padding columns to get an exact PANEL_WIDTH bitmap.
            val cropped = Bitmap.createBitmap(bitmap, 0, 0, PANEL_WIDTH, PANEL_HEIGHT)
            bitmap.recycle()
            cropped
        }
    }

    /**
     * Compresses the bitmap to JPEG, reducing quality progressively if the
     * result doesn't fit within MAX_FRAME_BYTES (the ESP32's reassembly
     * buffer size). Guarantees the returned byte array (if non-null) is
     * always small enough for the receiver to accept.
     */
    private fun compressToJpegWithinBudget(bitmap: Bitmap): ByteArray? {
        val qualitySteps = intArrayOf(60, 45, 30, 20)
        for (quality in qualitySteps) {
            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, stream)
            val bytes = stream.toByteArray()
            if (bytes.size <= MAX_FRAME_BYTES) {
                return bytes
            }
        }
        return null // Couldn't fit even at lowest quality - drop this frame.
    }

    /**
     * Fragments a JPEG byte array into UDP packets matching the receiver's
     * binary header format, and sends them over the socket.
     */
    private fun sendFrame(jpegBytes: ByteArray) {
        val sock = socket ?: return
        val addr = targetAddress ?: return

        val totalPackets = ((jpegBytes.size + MAX_PAYLOAD_BYTES - 1) / MAX_PAYLOAD_BYTES)
            .coerceAtLeast(1)

        val currentFrameId = frameId
        frameId = (frameId + 1) and 0xFFFF

        var offset = 0
        for (packetId in 0 until totalPackets) {
            val payloadLen = minOf(MAX_PAYLOAD_BYTES, jpegBytes.size - offset)

            val packet = ByteBuffer.allocate(HEADER_BYTES + payloadLen)
                .order(ByteOrder.LITTLE_ENDIAN)
            packet.putShort(PACKET_MAGIC.toShort())
            packet.putShort(currentFrameId.toShort())
            packet.putShort(packetId.toShort())
            packet.putShort(totalPackets.toShort())
            packet.putShort(payloadLen.toShort())
            packet.put(jpegBytes, offset, payloadLen)

            val datagram = DatagramPacket(
                packet.array(), packet.array().size, addr, UDP_PORT
            )
            try {
                sock.send(datagram)
            } catch (e: Exception) {
                // Network hiccup on a single fragment - skip it. The receiver's
                // frame timeout will discard the incomplete frame and the next
                // frame will proceed normally; retrying stale UDP data is not
                // useful for a real-time stream.
            }

            offset += payloadLen
        }
    }

    private fun handleStop() {
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        socket?.close()
        captureThread?.quitSafely()

        virtualDisplay = null
        imageReader = null
        mediaProjection = null
        socket = null
        captureThread = null
        captureHandler = null

        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        handleStop()
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "AR Glasses Streaming",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("AR Glasses Sender")
            .setContentText("Streaming screen to glasses...")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .build()
    }
}
