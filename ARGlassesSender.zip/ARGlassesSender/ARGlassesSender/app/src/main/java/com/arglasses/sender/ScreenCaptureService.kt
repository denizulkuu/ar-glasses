package com.arglasses.sender

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.io.ByteArrayOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Foreground service that owns the full sender pipeline:
 * MediaProjection -> VirtualDisplay -> ImageReader (RGBA_8888) -> Bitmap -> JPEG -> UDP
 *
 * Modified to automatically release and recreate VirtualDisplay when the screen turns OFF and ON.
 */
class ScreenCaptureService : Service() {

    companion object {
        const val ACTION_START = "com.arglasses.sender.action.START"
        const val ACTION_STOP = "com.arglasses.sender.action.STOP"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val EXTRA_TARGET_IP = "extra_target_ip"

        private const val NOTIFICATION_CHANNEL_ID = "ar_glasses_stream"
        private const val NOTIFICATION_ID = 1

        private const val PANEL_WIDTH = 240
        private const val PANEL_HEIGHT = 320
        private const val UDP_PORT = 5005
        private const val PACKET_MAGIC: Int = 0xA55A
        private const val HEADER_BYTES = 10
        private const val MAX_PACKET_BYTES = 1400
        private const val MAX_PAYLOAD_BYTES = MAX_PACKET_BYTES - HEADER_BYTES // 1390
        private const val MAX_FRAME_BYTES = 60 * 1024

        private const val MIN_FRAME_INTERVAL_MS = 33L
    }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var captureThread: HandlerThread? = null
    private var captureHandler: Handler? = null

    private var socket: DatagramSocket? = null
    private var targetAddress: InetAddress? = null

    private var frameId: Int = 0
    private var lastFrameSentAtMs: Long = 0
    private var isReceiverRegistered = false

    private val projectionManager: MediaProjectionManager by lazy {
        getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    }

    // --- Ekran Durumunu Dinleyen Alıcı (Auto-Resume Mekanizması) ---
    private val screenStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    // Ekran kapandığında gereksiz kaynak tüketimini önlemek için sanal ekranı serbest bırak
                    captureHandler?.post {
                        releaseVirtualDisplay()
                    }
                }
                Intent.ACTION_SCREEN_ON -> {
                    // Ekran açıldığında sanal ekranı ve ImageReader'ı otomatik olarak yeniden oluştur
                    captureHandler?.post {
                        if (mediaProjection != null) {
                            setupVirtualDisplay()
                        }
                    }
                }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> handleStart(intent)
            ACTION_STOP -> handleStop()
        }
        return START_NOT_STICKY
    }

    private fun handleStart(intent: Intent) {
        startForeground(NOTIFICATION_ID, buildNotification())

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, -1)
        val resultData: Intent? =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(EXTRA_RESULT_DATA)
            }
        val targetIp = intent.getStringExtra(EXTRA_TARGET_IP)

        if (resultData == null || targetIp.isNullOrEmpty()) {
            stopSelf()
            return
        }

        try {
            targetAddress = InetAddress.getByName(targetIp)
            socket = DatagramSocket()
        } catch (e: Exception) {
            stopSelf()
            return
        }

        captureThread = HandlerThread("ScreenCaptureThread").also { it.start() }
        captureHandler = Handler(captureThread!!.looper)

        mediaProjection = projectionManager.getMediaProjection(resultCode, resultData)
        mediaProjection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                handleStop()
            }
        }, captureHandler)

        // Dinamik olarak ekran kilitleme/açma olaylarını dinlemeye başla
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        registerReceiver(screenStateReceiver, filter)
        isReceiverRegistered = true

        setupVirtualDisplay()
    }

    private fun setupVirtualDisplay() {
        // Eski sanal ekran varsa temizle
        releaseVirtualDisplay()

        val density = resources.displayMetrics.densityDpi

        imageReader = ImageReader.newInstance(
            PANEL_WIDTH, PANEL_HEIGHT, PixelFormat.RGBA_8888, 2
        )

        imageReader?.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val now = System.currentTimeMillis()
                if (now - lastFrameSentAtMs < MIN_FRAME_INTERVAL_MS) {
                    return@setOnImageAvailableListener
                }
                lastFrameSentAtMs = now

                val bitmap = imageToBitmap(image)
                val jpegBytes = compressToJpegWithinBudget(bitmap)
                if (jpegBytes != null) {
                    sendFrame(jpegBytes)
                }
                bitmap.recycle()
            } catch (e: Exception) {
                // Ekran geçişlerinde oluşabilecek anlık kilitlenmeleri yut
            } finally {
                image.close()
            }
        }, captureHandler)

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "ARGlassesCapture",
            PANEL_WIDTH, PANEL_HEIGHT, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            captureHandler
        )
    }

    private fun releaseVirtualDisplay() {
        try {
            virtualDisplay?.release()
        } catch (e: Exception) {}
        virtualDisplay = null

        try {
            imageReader?.close()
        } catch (e: Exception) {}
        imageReader = null
    }

    private fun imageToBitmap(image: android.media.Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * PANEL_WIDTH

        val bitmap = Bitmap.createBitmap(
            PANEL_WIDTH + rowPadding / pixelStride,
            PANEL_HEIGHT,
            Bitmap.Config.ARGB_8888
        )
        bitmap.copyPixelsFromBuffer(buffer)

        return if (rowPadding == 0) {
            bitmap
        } else {
            val cropped = Bitmap.createBitmap(bitmap, 0, 0, PANEL_WIDTH, PANEL_HEIGHT)
            bitmap.recycle()
            cropped
        }
    }

    private fun compressToJpegWithinBudget(bitmap: Bitmap): ByteArray? {
        val qualitySteps = intArrayOf(60, 45, 30, 20)
        for (quality in qualitySteps) {
            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, stream)
            val bytes = stream.toByteArray()
            if (bytes.size <= MAX_FRAME_BYTES) {
                return bytes
            }
        }
        return null
    }

    private fun sendFrame(jpegBytes: ByteArray) {
        val sock = socket ?: return
        val addr = targetAddress ?: return

        val totalPackets = ((jpegBytes.size + MAX_PAYLOAD_BYTES - 1) / MAX_PAYLOAD_BYTES)
            .coerceAtLeast(1)

        val currentFrameId = frameId
        frameId = (frameId + 1) and 0xFFFF

        var offset = 0
        for (packetId in 0 until totalPackets) {
            val payloadLen = minOf(MAX_PAYLOAD_BYTES, jpegBytes.size - offset)

            val packet = ByteBuffer.allocate(HEADER_BYTES + payloadLen)
                .order(ByteOrder.LITTLE_ENDIAN)
            packet.putShort(PACKET_MAGIC.toShort())
            packet.putShort(currentFrameId.toShort())
            packet.putShort(packetId.toShort())
            packet.putShort(totalPackets.toShort())
            packet.putShort(payloadLen.toShort())
            packet.put(jpegBytes, offset, payloadLen)

            val datagram = DatagramPacket(
                packet.array(), packet.array().size, addr, UDP_PORT
            )
            try {
                sock.send(datagram)
            } catch (e: Exception) {}

            offset += payloadLen
        }
    }

    private fun handleStop() {
        if (isReceiverRegistered) {
            try {
                unregisterReceiver(screenStateReceiver)
            } catch (e: Exception) {}
            isReceiverRegistered = false
        }

        releaseVirtualDisplay()
        mediaProjection?.stop()
        socket?.close()
        captureThread?.quitSafely()

        mediaProjection = null
        socket = null
        captureThread = null
        captureHandler = null

        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        handleStop()
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "AR Glasses Streaming",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("AR Glasses Sender")
            .setContentText("Streaming screen to glasses...")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .build()
    }
}